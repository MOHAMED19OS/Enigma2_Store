#!/bin/sh
#### "***********************************************"
#### "*       ..:: Script by MOHAMED_OS ::..        *"
#### "*  Support: https://github.com/MOHAMED19OS    *"
#### "*       E-Mail: mohamed19eng@gmail.com        *"
#### "***********************************************"

CAMNAME="NCam_14.0"

remove_tmp() {
  rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/ncam* /tmp/.ncam
}

case "$1" in
start)
  remove_tmp
  /usr/bin/${CAMNAME} &
  ;;
stop)
  killall -9 ${CAMNAME} 2>/dev/null
  sleep 2
  remove_tmp
  ;;
*)
  $0 stop
  exit 0
  ;;
esac

exit 0
